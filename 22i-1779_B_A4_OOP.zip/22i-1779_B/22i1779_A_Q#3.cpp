/*
      NAME: ROZINA WALI
      ROLL NO.: 22I1779
      SECTION: D
      ASSIGNMENT: 05
      QUESTION: 03
*/
#include <iostream>
#include <string>
using namespace std;

class Textbook
{
private:
    string title;
    string author;
    string publisher;
public:
    //default constructor
    Textbook()
    {
        cout << "Default constructor" << endl;
    }
     //constructor user defined 
    Textbook( string t,  string a,string p)
    { 
        title = t;
        author = a;
        publisher = p;
    }

    Textbook(Textbook &sign)
    {
        sign.author = author;
        sign.title = title;
        sign.publisher = publisher;
    }
    void print()
    {
        cout << "Title of the Textbook: " << title<<endl;
        cout << "Author of the Textbook: " << author<<endl;
        cout << "Publisher of the Textbook: " << publisher<<endl;
    }
};

class Instructor
{
    string first_name;
    string last_name;
    string office_no;
public:
    // default constructor 
    Instructor()
    {
        cout << " Default constructor" << endl;
    }
    // constructor user defined 
    Instructor(string fname, string lname, string Ono)
    {
        first_name = fname;
        last_name = lname;
        office_no = Ono;
    }
    Instructor(Instructor& sign)
    {
        sign.first_name = first_name;
        sign.last_name = last_name;
        sign.office_no = office_no;
    }
    void print()
    {
        cout << "First name of instructor: " << first_name<< endl;
        cout << "Last name of instructor: " << last_name << endl;
        cout << "Office number of instructor: " << office_no << endl;
    }
};

class Course
{
    string name;
    Instructor* instructor;
    Textbook* textbook;

public:
    Course()
    {
        cout << "default constructor " << endl;
    }
    // constructor 
    Course( string name)
    { 
       this->name = name;
       this->instructor = nullptr;
       this->textbook = nullptr;
    }
    void set_instructor(Instructor* inst)
    {
       instructor = inst;
    }

    void set_textbook(Textbook* tbook) 
    {
        textbook = tbook;
    }

    void print()
    {
        cout << "Course Name: " << name << endl; 
    }

};

int main() 
{
    Instructor* instructor = new Instructor("Sir Jawad ", "Khan ", "C202");
    Textbook* textbook = new Textbook("C++ Programming", " Syed Saad" , "Fast");
    Course* course = new Course("Object Oriented Programming ");

    course->set_instructor(instructor);
    course->set_textbook(textbook);
    course->print();
    instructor->print();
    textbook->print();

    delete course;
    delete textbook;
    delete instructor;

    return 0;
}
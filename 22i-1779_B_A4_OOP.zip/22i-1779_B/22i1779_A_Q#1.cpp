/*
      NAME: ROZINA WALI
      ROLL NO. 22I1779
      SECTION: B
      ASSIGNMENT: 05
      QUESTION: 01
*/
#include <iostream>
#include <string>
using namespace std;

class ParkedCar
{
public:
    string carmake;
    string carmodel;
    string carcolor;
    int carlicense_number;
    int carminutes_parked;

    // Default constructor
    ParkedCar()
    {
        carmake = "";
        carmodel = "";
        carcolor = "";
        carlicense_number = 0;
        carminutes_parked = 0;
    }

    // User-defined constructor
    ParkedCar(string cma, string cmd, string ccl, int cln, int cmp)
    {
        carmake = cma;
        carmodel = cmd;
        carcolor = ccl;
        carlicense_number = cln;
        carminutes_parked = cmp;
    }
};

class ParkingMeter
{
public:
    int minutes_purchased;

    ParkingMeter(int cmp)
    {
        minutes_purchased = cmp;
    }
};

class ParkingTicket
{
public:
    ParkedCar car;
    int fine;
    string officer_name;
    int badge_number;

    ParkingTicket(ParkedCar c, int fn, string oname, int bn)
    {
        car = c;
        fine = fn;
        officer_name = oname;
        badge_number = bn;
    }
    void reprot()
    {
        cout << "Car Details:"<<endl;
        cout << "Make: " << car.carmake <<endl<< "Model: " << car.carmodel << endl;
        cout << "Color: " << car.carcolor <<endl<< "License Number: " << car.carlicense_number << endl;
        cout << "Fine: $" << fine<<endl;
        cout << "Officer Name: " << officer_name <<endl<< "Badge Number: " << badge_number <<endl;
    }
};

class PoliceOfficer
{
public:
    string name;
    int badge_number;

    PoliceOfficer(string oname, int badgeno)
    {
        name = oname;
        badge_number = badgeno;
    }

    ParkingTicket* inspect(ParkedCar& car, ParkingMeter& meter)
    {
        if (car.carminutes_parked > meter.minutes_purchased)
        {
            int il_minutes = car.carminutes_parked - meter.minutes_purchased;
            int fine = 25 + 10 * ((il_minutes - 1) / 60);
            return new ParkingTicket(car, fine, name, badge_number);
        }
        else
        {
            return nullptr;
        }
    }
};

int main()
{
    string carmake, carmodel;
    string carcolor, officer_name;
    int carlicense_number, carminutes_parked;
    int minutes_purchased, badge_number;

    cout << "Enter car make: ";
    cin >> carmake;
    cout << "Enter car model: ";
    cin >> carmodel;
    cout << "Enter car color: ";
    cin >> carcolor;
    cout << "Enter car license number: ";
    cin >> carlicense_number;
    cout << "Enter car minutes parked: ";
    cin >> carminutes_parked;
    cout << "Enter minutes purchased from parking meter: ";
    cin >> minutes_purchased;
    cout << "Enter officer name: ";
    cin >> officer_name;
    cout << "Enter officer badge number: ";
    cin >> badge_number;

    ParkedCar car(carmake, carmodel, carcolor, carlicense_number, carminutes_parked);
    ParkingMeter meter(minutes_purchased);
    PoliceOfficer officer(officer_name, badge_number);

    ParkingTicket* t = officer.inspect(car, meter);

    if (t != nullptr)
    {
        t->reprot();
        delete t;
    }
    else
    {
        cout << "No ticket issued.\n";
    }

    return 0;
}

/*
    NAME: ROZINA WALI 
    ROLL NO. 22I1779
    SECTION:B
    ASSIGNMENT: 05
    QUESTION: 02
*/
#include <iostream>
#include <string>
using namespace std;

class Book
{
private:
    string title;
    string author;
    int publication_year;

public:
    // default constructor 
    Book()
    {
        cout << "Default constructor call" << endl;
    }
    //  user defined constructor 
    Book(string t, string a, int p_year)
    {
        this->title = t;
        this->author = a;
        this->publication_year = p_year;
    }

    string getTitle()
    {
        return title;
    }

    string getAuthor()
    {
        return author;
    }

    int getPublicationYear()
    {
        return publication_year;
    }
};

class Bookshelf
{
private:
    static const int m_size = 50;
    Book* books[m_size];
    int size;

public:
    Bookshelf() : size(0) {}

    void addBook(Book* b)
    {
        if (size < m_size)
        {
            books[size] = b;
            size++;
        }
    }

    void listBooks()
    {
        for (int i = 0; i < size; i++)
        {
            cout << "Title: " << books[i]->getTitle() << endl;
            cout << "Author: " << books[i]->getAuthor() << endl;
            cout << "Publication Year: " << books[i]->getPublicationYear() << endl;
            cout << endl;
        }
    }
};

class Library
{

private:
    Bookshelf* bookshelf;
public:
    Library()
    {
        bookshelf = new Bookshelf();
    }

    ~Library()
    {
        delete bookshelf;
    }

    void addBookToShelf(Book* b)
    {
        bookshelf->addBook(b);
    }

    void listBooksInShelf()
    {
        bookshelf->listBooks();
    }
};

int main()
{
    Library library;

    Book book1("Book 1", "Abu Bakr KHan", 2018);
    Book book2("Book 2", "Azan KHAN", 2020);
    Book book3("Book 3", "Irfa KHAN", 2022);
    Book book4("Book 4", "Dua Khan", 2019);
    Book book5("Book 5", "Muhammad Sufyan", 2021);
    Book book6("Book 6", "Abdul Ahad", 2023);

    // books add in a library 
    library.addBookToShelf(&book1);
    library.addBookToShelf(&book2);
    library.addBookToShelf(&book3);
    library.addBookToShelf(&book4);
    library.addBookToShelf(&book5);
    library.addBookToShelf(&book6);
    library.listBooksInShelf();

    return 0;
}

/*
       NAME: ROZINA WALI
       ROLL NO. 22I1779
       SECTION: B
       ASSINMENT: 03 
       PROGRAM: 07
*/
#include <iostream>
using namespace std;

class Account
{
private:
    float balance;

public:
    Account()
    {
        balance = 0;
    }
    Account(float amount)
    {
        balance = amount;
    }
    void setAmount(float a)
    {
        balance = a;
    }
    float getAmount()
    {
        return balance;
    }
    void deposit(float amount)
    {
        balance += amount;
    }
    bool withdraw(float amount)
    {
        if (balance >= amount)            // agr balance zyada ho ga jo amount nikalwani h to balance mai sa wo amount minus ho jay gi
        {
            balance -= amount;
            return true;
        }
        else
        {
            balance =balance - 5; // nhi to penality deni ho gi 
            return false;
        }
    }
    float inquire()
    {
        return balance;
    }
};

int main()
{
    float balance;
    int choice;
    float amount;
    // bank balance user sa input karway ga 
    cout << "Enter your bank balance: ";
    cin >> balance;
    Account A(balance);

    cout << "1. Deposit\n2. Withdraw\n";
    cout << "Enter your choice: ";
    cin >> choice;
    switch (choice)
    {
    case 1:
        // case 1 mai agr wo paise deposit krna chahe ga 
        cout << "Enter the amount you want to deposit: ";
        cin >> amount;
        A.deposit(amount);
        cout << "Your current balance is: " << A.inquire();      
        break;
    case 2:
        cout << "Enter the amount you want to withdraw: ";
        cin >> amount;
        if (!A.withdraw(amount))
        {
            //agr koi raqam nhi ho gi account mai to 
            cout << "\n\n#############################################\n\n";
            cout << "Your account has no money." << endl;
            cout << "Your account has been charged with a penalty of $5." << endl;
            cout << "Your current balance is: " << A.inquire() << endl;
            cout << "\n\n#############################################\n\n";
        }
        else
        {
            // nhi to transaction ho gi successfully 
            cout << "\n\n#############################################\n\n";
            cout << "Your transaction was successful." << endl;
            cout << "Your current balance is: " << A.inquire() << endl;
            cout << "\n\n#############################################\n\n";
        }
        break;
    default:
        break;
    }
    return 0;
}
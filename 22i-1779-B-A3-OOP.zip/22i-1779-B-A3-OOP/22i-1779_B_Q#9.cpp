/*
	   NAME: ROZINA WALI
	   ROLL NO. 22I1779
	   SECTION: B
	   ASSIGNMENT: 03
	   PROGRAM: 09
*/
#include <iostream>
using namespace std;

class Rectangle
{
private:
    //private data
    float length;
    float width;

public:
    // Constructor
    Rectangle()
    {
        length = 0.0;
        width = 0.0;
    }

    // length or width display kary ga 
    void show() const
    {
        cout << "Length: " << length << endl;
        cout << "Width: " << width << endl;
    }

    // Setter for length
    void setLength(float len)
    {
        length = len;
    }

    // Setter for width
    void setWidth(float wid)
    {
        width = wid;
    }

    // perimeter calculate kary ga 
    float perimeter() const
    {
        return 2 * (length + width);
    }

    // area calculate kary ga 
    float area() const
    {
        return length * width;
    }

    //triangles ka area compere kar ga ka asame h ya nhi
    int sameArea(Rectangle otherRect) const
    {
        return (area() == otherRect.area()) ? 1 : 0;
    }
};

int main()
{
    // user sa input le ga lenth and width 
    float length, width;
    cout << "Enter the length of your rectangle: ";
    cin >> length;
    cout << "Enter the width of your rectangle: ";
    cin >> width;

    //first rectangle 
    Rectangle myRectangle;
    myRectangle.setLength(length);
    myRectangle.setWidth(width);

    //rectangle ki details show kary ga first waly ki 
    cout << "Rectangle Details:" << endl;
    myRectangle.show();
    cout << "Perimeter: " << myRectangle.perimeter() << endl;
    cout << "Area: " << myRectangle.area() << endl;
 
    // dosre rectangle ka leght or width khud pass karyn ga 
    Rectangle anotherRectangle;
    anotherRectangle.setLength(5.0);
    anotherRectangle.setWidth(4.0);

    cout << "\nComparing with another rectangle: ";
    if (myRectangle.sameArea(anotherRectangle))
    {
        cout << "They have the same area." << endl;    //agr same ho 
    }
    else
    {
        cout << "They don't have the same area." << endl;  // agr same na ho 
    }
    return 0;
}
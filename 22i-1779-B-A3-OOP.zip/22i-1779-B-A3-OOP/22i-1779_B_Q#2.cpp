/*
       NAME: ROZINA WALI
       ROLL NO.: 22I1779
       SECTION: D
       ASSIGNMENT:03
       PROGRAM: 02
*/
#include <iostream>
using namespace std;

class Car
{
private:
    float fuelEfficiency;  // Miles per gallon or liters per km
    float fuelLevel;       // Current fuel ka  level

public:
    // Constructor 
    Car(float eff) : fuelEfficiency(eff), fuelLevel(0.0)
    {

    }

    // Method jis mai car kitna drive kary ga 
    void drive(float distance) 
    {
        if (fuelEfficiency > 0.0)
        {
            fuelLevel -= distance / fuelEfficiency;
            if (fuelLevel < 0.0)
            {
                fuelLevel = 0.0;  // agr zero sa km ho ga fuel level to 0 distance kar sakta h
            }
        }
    }
    // Method jis mai current fuel level ka pata lagy ga 
    float getFuelLevel() const
    {
        return fuelLevel;
    }
    void tank(float amount)
    {
        if (amount > 0.0)
        {
            fuelLevel += amount;
        }
    }
};

int main()
{
    Car myBeemer(29); 

    cout << myBeemer.getFuelLevel() << endl;  // Should output 0.0
    myBeemer.tank(20);  // Tank  20 units  fuel
    cout << myBeemer.getFuelLevel() << endl;  
    myBeemer.drive(100); 
    cout << myBeemer.getFuelLevel() << endl; 

    return 0;
}
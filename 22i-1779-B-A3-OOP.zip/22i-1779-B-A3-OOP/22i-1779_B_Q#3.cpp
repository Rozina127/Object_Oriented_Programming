/*
       NAME: ROZINA WALI 
       ROLL NO.: 22I1779
       SECTION: D
       ASSIGNMENT:03
       PROGRAM: 03
*/
#include <iostream>
using namespace std;

class Circle 
{
private:
    float radius;  //circle ka radius 

public:
    // Constructor 
    Circle(float r) : radius(r)
    {
        radius = r;
    }

    // Method jo area of circle calculate kary ga 
    float getArea() const
    {
        return 3.14159265* radius * radius;
    }

    // Method jis mai circumference calculate ho ga 
    float getCircumference() const
    {
        return 2 * 3.14159265 * radius;
    }
};

int main()
{
    float radius;   
    cout << "Enter the radius of your circle: ";         // user sa input leni h    
    cin >> radius;

    Circle myCircle(radius);              

    cout << "Area: " << myCircle.getArea() << endl;    //get area function cal ho ga or area ki value prnt ho gi
    cout << "Circumference: " << myCircle.getCircumference() << endl;     // get circunference  function cal ho ga or area ki value prnt ho gi
    cout << "Good-bye!" << endl;    // program end sho

    return 0;
}
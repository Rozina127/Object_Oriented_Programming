/*
       NAME: ROZINA WALI
       ROLL NO.: 22I1779
       SECTION: D
       ASSIGNMENT:03
       PROGRAM: 01
*/
#include <iostream>
#include <string>
using namespace std;
class Employee
{
private:
    int Id;
    string name;
    double salary;
    

public:
    Employee(int id = 1, string n = "A", double s = 0.0) : Id(id), name(n), salary(s)
    {
        // Constctor default values ka sath
    }

    // Getter or setter funtions 
    void setId(int i)
    {
        Id = i;
    }

    int getId() const 
    {
        return Id;
    }

    void setName(const string& n)
    {
        name = n;
    }

    string getName() const
    {
        return name;
    }

    void setSalary(double s)
    {
        salary = s;
    }

    double getSalary() const
    {
        return salary;
    }

    // Utility function jo ka constant h 
    void displayDetails() const
    {
        cout << "Employee ID: " << getId() << endl;
        cout << "Employee Name: " << getName() <<endl;
        cout << "Employee Salary: " << getSalary() << endl;
       
    }
};

int main()
{
    Employee emp1;  // Default constructor call ho ga 
    emp1.displayDetails();
    return 0;
}
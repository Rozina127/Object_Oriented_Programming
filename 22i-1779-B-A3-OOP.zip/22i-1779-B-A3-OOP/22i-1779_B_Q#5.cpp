/*
       NAME: ROZINA WALI
       ROLL NO.: 22I1779
       SECTION: D
       ASSIGNMENT:03
       PROGRAM: 05
*/
#include <iostream>
using namespace std;

class Employee2
{
private:
    //private data
    char Name[20];
    float HourlyWage;
    float WorkedHours;
    float ExtraHours;

public:
    float wageCalculator()
    {
        // ser sa input le ga 
        cout << "Please enter employee's name then press Enter: ";
        cin.getline(Name, sizeof(Name));

        cout << "Please enter hourly wage then press Enter: ";
        cin >> HourlyWage;

        cout << "Please enter hours worked then press Enter: ";
        cin >> WorkedHours;

        float totalPayment = 0.0;
        //work hour check hon gi agr 40 sa zyada hon gi to extra hour ki bhi sath calculate akry ga 
        if (WorkedHours > 40.0)
        {
            ExtraHours = WorkedHours - 40.0;
            totalPayment = (40.0 * HourlyWage) + (ExtraHours * HourlyWage * 1.5);

            //overtime details print kary ga nhi to else mai jay ga agr 40 sa kam howe hourrly rate
            cout << "########################################";
            cout << "\nPaycheck for employee " << Name << endl<<endl;
            cout << "Hours worked: " << WorkedHours << endl;
            cout << "Hourly wage: " << HourlyWage << endl;
            cout << "Overtime hours: " << ExtraHours << endl;
            cout << "Overtime hourly wage: " << (HourlyWage * 1.5) << endl;
        }
        else
        {
            cout << "#########################################";
            cout << "\nPaycheck for employee " << Name << endl<<endl;
            cout << "Hours worked: " << WorkedHours << endl;
            cout << "Hourly wage: " << HourlyWage << endl;
            totalPayment = WorkedHours * HourlyWage;
        }

        // Print total payment
        cout << "Total payment: " << totalPayment << endl;

        return totalPayment;
    }
};

int main()
{
    Employee2 e;
    float totalPayment = e.wageCalculator();
    cout << "\n#######################################\n"<<endl;

    return 0;
}
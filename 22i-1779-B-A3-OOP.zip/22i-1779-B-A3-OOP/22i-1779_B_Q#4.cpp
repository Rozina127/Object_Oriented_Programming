/*
       NAME: ROZINA WALI
	   ROLL NO. 22I1779
	   SECTION: B
	   ASSIGNMENT: 03
	   PROGRAM: 04
*/
#include <iostream>
using namespace std;
class Flightinfo
{
private:
	//private data memebers 	
	int flight_num;
	char* destination = new char[20];
	float distance;
	float fuel;

public:
	//public function
	void feedinfo()
		//function jo k user sa dat input le ga 
	{
		cout << "Enter Flight number\t:\t";
		cin >> flight_num;
		cout << "Enter destination\t:\t";
		cin >> destination;
		cout << "Enter distance\t:\t";
		cin >> distance;

	}
	// detination return kary ga
	char* getDestination()
	{
		return destination;
	}

	void calfuel()
		//functions jo k fuel ki limits ko check kary gA 
	{
		if (distance <= 1000)
		{
			fuel = 500;
		}
		else if (distance > 1000 && distance <= 2000)
		{
			fuel = 1100;
		}
		else
		{
			fuel = 2200;
		}
	}

	void showinfo()
		//functin jo ka information display kary ga 
	{
		cout << endl << endl << "################################################" << endl << endl;
		cout << "Flight number\t:\t" << flight_num << endl;
		cout << "Destination\t:\t" <<destination << endl;
		cout << "Distance\t:\t" <<distance << endl;
		cout << "Fuel quantity\t:\t" << fuel << endl;
		cout << endl << endl << "################################################" << endl << endl;
	}

	float getfuel()
	{
		return fuel;
	}

	~Flightinfo()
		//destructor.
	{
		cout << endl << endl << "################################################" << endl << endl;
		cout << endl << "This is the destructor." << endl;
	}
};

int main()
{
	//class ka object 
	Flightinfo f;

	//functions ka calling 
	f.feedinfo();
	f.calfuel();
	f.showinfo();
	

	cout << endl << "Fuel\t\t:\t" << f.getfuel();
	char* temp = f.getDestination();
	delete temp;
	temp = NULL;
}//end OF THE PROGRAM 


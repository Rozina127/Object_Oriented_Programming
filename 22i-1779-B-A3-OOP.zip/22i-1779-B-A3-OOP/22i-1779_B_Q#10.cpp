/*
       NAME: ROZINA WALI
       ROLL NO. 22I1779
       SECTION: B
       ASSIGNMENT: 03
       PROGRAM: 10
*/
#include <iostream>
using namespace std;

class IntArray
{
private:
    int* arr;
    int size;

public:
    IntArray()
    {
        arr = nullptr;
        size = 0;
    }

    IntArray(int sizel)
    {
        size = sizel;
        arr = new int[size];
    }

    IntArray(const IntArray& obj)
    {
        size = obj.size;
        arr = new int[size];
        for (int i = 0; i < size; i++)
        {
            arr[i] = obj.arr[i];
        }
    }

    ~IntArray()
    {
        delete[] arr;
    }

    int getAt(int idx)
    {
        if (idx >= 0 && idx < size)
        {
            return arr[idx];
        }
        else
        {
            cout << "out of range";
        }
    }

    void setAt(int idx, int val)
    {
        if (idx >= 0 && idx < size) 
        {
            arr[idx] = val;
        }
        else 
        {
            cout << "Index out of range";
        }
    }

    // Insert kary ga value specific index pa 
    int insert(int idx, int val)
    {
        if (idx >= 0 && idx <= size)
        {
            int* temp = new int[size + 1];
            for (int i = 0; i < idx; i++)
            {
                temp[i] = arr[i];
            }
            temp[idx] = val;
            for (int i = idx; i < size; i++)
            {
                temp[i + 1] = arr[i];
            }
            size++;
            delete[] arr;
            arr = temp;
            return 1;
        }
        else {
            cout << "Index out of range";
        }
    }

    // array k occurance find kary  ga at indexes 
    IntArray find(int val)
    {
        int count = 0;
        for (int i = 0; i < size; i++)
        {
            if (arr[i] == val)
            {
                count++;
            }
        }

        IntArray temp(count);
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (arr[i] == val) {
                temp.setAt(j, i);
                j++;
            }
        }
        return temp;
    }

    // ARRAY KI LENGHT
    int length() {
        return size;
    }
    // array ka element ko display kary ga 
    void display()
    {
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    //array ko sort kary ga in accending order mai 
    void sort()
    {
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = 0; j < size - i - 1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    int temp = arr[j];      //sort
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    // Reverse kary ga array ka element ko
    void reverse() 
    {
        for (int i = 0; i < size / 2; i++)
        {
            int temp = arr[i];
            arr[i] = arr[size - i - 1];
            arr[size - i - 1] = temp;
        }
    }

    // array ko clear kary ga 
    void clear()
    {
        delete[] arr;
        arr = nullptr;
        size = 0;
    }

    // Check kary ga k array empty h ya nhi 
    bool empty() 
    {
        return size == 0;
    }
};

int main()
{
    //array obj create kary ga 
    IntArray intArray(5);

    // array ko value assign kary ga 
    for (int i = 0; i < 5; i++)
    {
        intArray.setAt(i, i * 2);
    }

    // array ka elements display kary ga 
    cout << "Array contents: ";
    intArray.display();

    // new value insert kary ga 
    intArray.insert(2, 42);

    // Display kary ga updated array ko
    cout << "Array contents after insertion: ";
    intArray.display();

    // new value ki occurance find kary ga 
    IntArray foundIndexes = intArray.find(42);

    //index diplay kary ga new value ka 
    cout << "Indexes where 42 is found: ";
    foundIndexes.display();

    // array sort 
    intArray.sort();

    // sorted array ko display kary ga 
    cout << "Sorted array: ";
    intArray.display();

    // array reverse 
    intArray.reverse();

    // reverse array ko display kary ga 
    cout << "Reversed array: ";
    intArray.display();
    return 0;
}
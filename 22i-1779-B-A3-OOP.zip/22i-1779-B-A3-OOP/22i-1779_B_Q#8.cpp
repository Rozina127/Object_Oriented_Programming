/*
       NAME: ROZINA WALI 
	   ROLL NO.: 22I1779
	   SECTION: B
	   ASSIGNMENT :03
	   PROGRAM: 08
*/
#include <iostream>
using namespace std;
class Student
{
private:
	char* Roll_Number;
	char* Name;
	int Batch;
	int Courses_Code[5];            //5 couses ka code le ga 
	char** Courses_Name;

	char Courses_Grades[5];       //5 couses ka grades le ga 
	float CGPA;
	char* Degree = new char[20];
	char* DOB = new char[20];

public:
	Student()
	{
		Roll_Number = new char[20];
		Name = new char[20];
		Courses_Name = new char* [5];            //5 couses ka name le ga 
		for (int i = 0; i < 5; i++) {
			Courses_Name[i] = new char[20];
		}
		Degree = new char[20];
		DOB = new char[20];
	}

	// Destructor
	~Student()
	{
		delete[] Roll_Number;
		delete[] Name;
		for (int i = 0; i < 5; i++) {
			delete[] Courses_Name[i];      //5 couses ko heap sa delete kary ga destructor 
		}
		delete[] Courses_Name;
		delete[] Degree;
		delete[] DOB;
	}

	void setcoursecode(int array[5])     //coutrses code ko set kary ga 
	{
		for (int i = 0; i < 5; i++)
		{
			Courses_Code[i] = array[i];
		}
	}
	void setcoursename(char* array[5])   //courses name ko set kary ga 
	{
		for (int i = 0; i < 5; i++)
		{
		   Courses_Name[i] = array[i];
		}
	}
	void setcoursegrade(char array[5])     //courses ka grades set kary gav
	{
		for (int i = 0; i < 5; i++)
		{
		   Courses_Grades[i] = array[i];
		}
	}
	void setBatch(int batch)     //batch of sstudent set kary ga 
	{
	      Batch = batch;
	}
	void setCgpa(float cgpa)    //student ka gpa set kary ga 
	{
		CGPA = cgpa;
	}
	void setDdegree(char* degree) // student ki degree ka name set kary ga 
	{
		Degree = degree;
	}

	void setDob(char* dob)      //student ka date of birth set kary ga 
	{
		DOB = dob;
	}

	void setName(char* name)    //student name set kary ga 
	{ 
		Name = name;
	}

	void setRollNumber(char* rollNumber)  // student roll no. set kary ga 
	{
		Roll_Number = rollNumber;
	}
	// display kary ga sari information 
	void displayinfo()
	{
		int tempcrd = 0;
		cout << "############################################################################################";
		cout << "\n\nStudent name:\t" << (Name) << "\t\t\t\t\tRoll no:\t" << (Roll_Number) << endl << endl;
		cout << "DOB:\t" << (DOB) << "\t\tUni Reg No: " << (Roll_Number) << "\t\t\tDegree:\t" << (Degree) << endl;
		cout << "\t\t\t\t" << (Batch) << endl;
		cout << "\n\n\t\tCode\t\tCourse Title\t\tCrdts\tGrade\tRmk\n";
		for (int i = 0; i < 5; i++)
		{
			cout << "\t\t" << (Courses_Code[i]) << "\t\t" << (Courses_Name[i]) << "\t\t\t\t3\t\t" << (Courses_Grades[i]) << endl;
			tempcrd += 3;
		}
		cout << "###########################################################################################";
		cout << "\t\t\tCredits attempted: " << tempcrd << "\t\tGPA:" << (CGPA) << endl;
		cout << "\t\t\tCredits earned: " << tempcrd << "\t\tCGPA: " << (CGPA) << endl;
	}
	//agr koi information update krni ho to 
	void updateinfo()
	{
		int temp;
		cout << "1.Course_Codes.\n2.Course_Names.\n3.Course_Grades.\n4.Batch\n.5CGPA\n6.Degree\n.7DOB\n8.Name\n9.Roll number.\n10.Exit\n";
		cout << "Enter your choice\t:\t";
		cin >> temp;
		switch (temp)
		{
		case 1:
			for (int i = 0; i < 5; i++)
			{
				cout << "Enter Course code\t:\t";
				cin >> Courses_Code[i];
				cin.ignore();
			}
			break;
		case 2:
			for (int i = 0; i < 5; i++)
			{
				cout << "Enter Course Name\t:\t";
				cin.getline(Courses_Name[i], 20, '\n');
				cin.ignore();
			}
			break;
		case 3:
			for (int i = 0; i < 5; i++)
			{
				cout << "Enter Course Grade\t:\t";
				cin >> Courses_Grades[i];
				cin.ignore();
			}
			break;
		case 4:
			cout << "Enter Batch\t:\t";
			cin >> Batch;
			break;
		case 5:
			cout << "Enter CGPA\t:\t";
			cin >> CGPA;
			break;
		case 6:
			cout << "Enter Degree\t:\t";
			cin >> Degree;
			break;
		case 7:
			cout << "Enter DOB\t:\t";
			cin >> DOB;
			break;
		case 8:
			cout << "Enter Name\t:\t";
			cin >> Name;
			break;
		case 9:
			cout << "Enter Roll Number\t:\t";
			cin >> Roll_Number;;
			break;
		default:
			return;
		}
		displayinfo();
	}

	// sari inputs le ga 
	void studentDemo()
	{
		cout << "Enter Roll Number\t:\t";
		cin >> Roll_Number;
		cin.ignore();

		cout << "Enter Name\t:\t";
		cin.getline(Name, 20, '\n');

		cout << "Enter Batch\t:\t";
		cin >> Batch;

		cout << "Enter CGPA\t:\t";
		cin >> CGPA;
		cin.ignore();

		cout << "Enter Degree\t:\t";
		cin.getline(Degree, 20, '\n');

		cout << "Enter DOB\t:\t";
		cin.getline(DOB, 20, '\n');

		for (int i = 0; i < 5; i++)
		{
			cout << "Enter Course code\t:\t";
			cin >> Courses_Code[i];
		}
		cin.ignore();

		for (int i = 0; i < 5; i++)
		{
			cout << "Enter Course Name\t:\t";
			cin.getline(Courses_Name[i], 20, '\n');

			cout << "Enter Course Grade\t:\t";
			cin >> Courses_Grades[i];
			cin.ignore();
		}

		displayinfo();    //information display ko CAL ho ga information display krne ka lia 
	}
};
//class end.


int main()
{
	Student a;
	a.studentDemo();


	char say;
	//agr koi updation krne ho to 
	cout << "\n\nDo you want to update anything?(y/n)";
	cin >> say;
	if (say == 'y')
	{
		a.updateinfo();      //agr krne h to wo function ko dobara cal kary ga
	}
	else 
	{  
		cout << "\n\t\tThank You For Visiting Us!\n";    //nhi to program end  
	}

	return 0;

}









/*
      NAME: ROZINA WALI
	  ROLL NO.: 22I1779
	  SECTION: D
	  ASSIGNMENT: 03
	  PROGRAM: 06
*/
#include <iostream>
using namespace std;
class Address
{
	// private data 
	int HouseNumber;
	int Street;
	int ApartmentNumber;
	char* City = new char[20];
	char* State = new char[100];
	int PostalCode;
public:
	//constructor 
	Address()
	{
	}

	Address(int houseno, int street, int apartmentno, char* city, char* state, int postalcode)
	{
		HouseNumber = houseno;
	    Street = street;
		ApartmentNumber = apartmentno;
		City = city;
		State = state;
		PostalCode = postalcode;
	}

	//setter or getter functions 
	void setHouseNumber(int Hno)
	{
		HouseNumber = Hno;
	}
	int getHouseNumber()
	{
		return HouseNumber;
	}
	void setStreet(int strt)
	{
		Street = strt;
	}
	int getStreet()
	{
		return Street;
	}
	void setApartment(int a)
	{
		ApartmentNumber = a;
	}
	int getApartmentNumber()
	{
		return ApartmentNumber;
	}
	void setCity(char* cty)
	{
		City = cty;
	}
	char* getCity()
	{
		return City;
	}
	void setstate(char* state)
	{
		State = state;
	}
	char* getState()
	{
		return State;
	}
	void setPostalcode(int pst)
	{
		PostalCode = pst;
	}
	int getPostalcode()
	{
		return PostalCode;
	}
	// addres print kne ka function 
	void print()
	{
		cout << "Address :\n";
		cout << Street;
		cout << endl << City << ", " << State << ", " <<PostalCode << ".\n";
	}
	//camparision postl adrresses ka 
	bool compareTo(Address& b)
	{
		if (PostalCode < b.PostalCode)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//destructor q k dynamic memory allocate ki yh 
	~Address()
	{
		delete State;
		delete City;
		State = NULL;
		City = NULL;
	}
};

int main()
{
	int H_Num;
	int street;
	int Apartment_Num;
	char* city = new char[30];
	char* state = new char[30];
	int Post_code;
	//	Address(int houseno, int street, int apartmentno, char* city, char* state, int postalcode)

	Address A1, A2;

	cout << "\n\n######################################\n\n";

	cout << "Enter first Address :\n\n";

	cout << "Enter your House number\t:\t";
	cin >> H_Num;
	cout << "Enter street number\t:\t";
	cin >> street;
	cout << "Enter your Apartment number\t:\t";
	cin >> Apartment_Num;
	cout << "Enter name of your city\t:\t";
	cin >> city;
	cout << "Enter your name of the state\t:\t";
	cin >> state;
	cout << "Enter your Postal code\t:\t";
	cin >> Post_code;
	cout << "\n\n######################################\n\n";

	A1.setHouseNumber(H_Num);
	A1.setStreet(street);
	A1.setApartment(Apartment_Num);
	A1.setCity(city);
	A1.setstate(state);
	A1.setPostalcode(Post_code);
	// second addres le ga 
	cout << "Enter second Address :\n\n";

	cout << "Enter your House number\t:\t";
	cin >> H_Num;
	cout << "Enter street number\t:\t";
	cin >> street;
	cout << "Enter your Apartment number\t:\t";
	cin >> Apartment_Num;
	cout << "Enter name of your city\t:\t";
	cin >> city;
	cout << "Enter your name of the state\t:\t";
	cin >> state;
	cout << "Enter your Postal code\t:\t";
	cin >> Post_code;

	cout << "\n\n######################################\n\n";

	A2.setHouseNumber(H_Num);
	A2.setStreet(street);
	A2.setApartment(Apartment_Num);
	A2.setCity(city);
	A2.setstate(state);
	A2.setPostalcode(Post_code);

	A1.print();   //A1 ka lia print function cal h oga 
	cout << "\n\n######################################\n\n";
	A2.print();   //A2 ka lia print function cal ho ga 
	cout << "\n\n######################################\n\n";
	bool temp = A1.compareTo(A2);    //comparison kary ga 

	if (temp == true)
	{
	//agr pehla adrees chota ho ga 
	cout << "one address comes before another when the addresses are compared by postal code.\n";
	}
	else
	{
		//pehla addres bara ho ga 
		cout << "one address does not comes before another when the addresses are compared by postal code.\n";
	}
	cout << "\n\n######################################\n\n";
}
/*
    NAME ;ROZINA WALI
    ROLL NO.: 22I-1779
    SECTION: B
    ASSIGNMENT: 02
    PROGRAM: 04
*/
#include <iostream>
using namespace std;

// functions prototypes 
bool Safe_column(char** board, int row, int col);
bool iSafeTopleftDiagonal(char** board, int row, int col);
bool isSafeBottomLeftDiagonal(char** board, int row, int col, int N);
bool is_safe(char** board, int row, int col, int N);
bool Queens(char** board, int col, int N);
bool Queen_placement(char** board, int col, int N, int row);

// Main function sa functions ko call honge
int main()
{
    int N;
    cout << "Enter the size of the chess board: ";   // User sa input lena hai chess board ka size
    cin >> N;

    // Agar user chess board ka size 0 ya us se kam de de to invalid input hoga
    if (N <= 0)
    {
        cout << "Invalid board size." << endl;
        return 1;
    }

    // Chessboard ke liye dynamic memory allocation
    char** board = new char* [N];
    for (int i = 0; i < N; ++i)
        board[i] = new char[N];

    // Chess board banao - ka 
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            board[i][j] = '_';

    // Queens function ko call kar ke solution dhoondo
    if (!Queens(board, 0, N)) // Agar koi solution nahi mila
        cout << "solution not found";
    else
        // Solution board ko print karo
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j)
                cout << board[i][j] << " "; // Board ko print karo
            cout << "\n";
        }

    // Memory deallocate karo
    for (int i = 0; i < N; ++i)
        delete[] board[i];
    delete[] board;

    return 0;
}

// Ye function check kre ga ke kya ek queen board[row][col] par rakh sakti hai colums safe h us ka lia ya nhi
bool Safe_column(char** board, int row, int col)
{
    if (col < 0) 
        return true;

    if (board[row][col] == 'Q') // Agar current cell par queen hai, toh unsafe hai
        return false;

    // colum sa aik minus kr k ab check karo 
    return Safe_column(board, row, col - 1);
}

// Ye function check kre ga ke kya queen  diagonal par rakh sakti hai
bool isSafeTopLeftDiagonal(char** board, int row, int col)
{
    if (row < 0 || col < 0) 
        return true;

    if (board[row][col] == 'Q') // Agar current cell par queen hai, toh unsafe hai
        return false;

   
    return isSafeTopLeftDiagonal(board, row - 1, col - 1);
}

// Ye function check kary ga  diagonal par rakh sakti hai
bool isSafeBottomLeftDiagonal(char** board, int row, int col, int N)
{
    if (row >= N || col < 0)
        return true;

    if (board[row][col] == 'Q') // Agar current cell par queen hai, toh unsafe hai
        return false;

   
    return isSafeBottomLeftDiagonal(board, row + 1, col - 1, N);
}

// Ye function check karta hai ke kya ek queen board[row][col] par rakh sakti hai
bool is_safe(char** board, int row, int col, int N)
{
    return Safe_column(board, row, col) &&
        isSafeTopLeftDiagonal(board, row, col) &&
        isSafeBottomLeftDiagonal(board, row, col, N);    //agr teno condition thk h to wahan pr rakh saktai h queen
}

bool Queens(char** board, int col, int N) 
{
    if (col >= N) // Base case: Agar saari queens rakh di gayi hain
        return true;

    return Queen_placement(board, col, N, 0);   // queen ko replace krna h ya nhi us function mai ja k check kary ga conditions
}

// Ye function try karta hai ke queen rakhne ki koshish kare specific row mein
bool Queen_placement(char** board, int col, int N, int row)
{
    if (row >= N) 
        return false;

    if (is_safe(board, row, col, N))
    {
        board[row][col] = 'Q'; // safe row or colum h to Queen ko rakh do

        if (Queens(board, col + 1, N)) // Agle column mein queen rakhne ki koshish karo recursively
            return true;

        board[row][col] = '_'; // Agar agli column mein solution nahi mila toh backtrack karo
    }

    return Queen_placement(board, col, N, row + 1); // Agli row ki taraf jao
}
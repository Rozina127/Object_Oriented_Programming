/*
     NAME: ROZINA WALI
     ROLL NO.: 22I-1779
     SECTION:B 
     PROGRAM:01
     ASSIGNMENT: 02
*/
#include <iostream>
using namespace std;
//  kangaroo pairs calculate krne ka recursive function 
int kangaro_pairs(int months)
{
    // Base case: agr mobths 2 sa kam hon ga to no pair breed 
    if (months <= 2) 
    {
        return 1;
    }
    // Recursive case
    //sum krna h prevoius DO monthS KA
    else
    {
        return kangaro_pairs(months - 1) + kangaro_pairs(months - 2);
    }
}

int main()
{
    int months;
    // user sa months enter krwa raha h
    cout << "Enter the number of months: ";
    cin >> months;
    cout << "Number of kangaroo pairs after " << months << " months: " << kangaro_pairs(months) << endl;
    return 0;
}
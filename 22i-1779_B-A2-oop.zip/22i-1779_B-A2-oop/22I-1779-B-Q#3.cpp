/*
   NAME: ROZINA WALI
   ROLL NO.: 22I-1779
   SECTION: B
   ASSIGNMENT: 02
   PROGRAM: 03
*/ 
#include <iostream>
using namespace std;
// Recursive function 
// FUNCTION JO K FACTORIAL CALCULATE KARY GA
long factorial(int n)
{
    if (n == 0)
        return 1;
    else
        return n * factorial(n - 1);
}

// Function JO K PERMUTATION KO CALCULATE KARY GA
long permutations(int n, int r)
{
    return factorial(n) / factorial(n - r);
}

int main()
{
    int n, r;
    //factorial or permutation ka lia user sa input lena h 
    cout << "Enter the total number of items (n): "<<endl;
    cin >> n;
    cout << "Enter the number of items to choose (r): "<<endl;
    cin >> r;
    cout << "Number of unique permutations of " << r << " items from a group of " << n << " items: " << permutations(n, r) <<endl;
    return 0;
}
/*
     NAMER: ROZINA WALI
     ROLL NO.:22I-1779
     SECTION: B
     ASSIGNMENT: 02
     PROGRAM: 02
*/
#include <iostream>
using namespace std;

// FUNCTION TO PRINT CHARACTER 1 (*)
void PrintChar1(char char1, int times)
{
    if (times == 0)
    {
        return;
    }
    else
    {
        cout << char1;
    }

    PrintChar1(char1, times - 1);//odd row mai ho ga to times mai sa 1 minus kary ga or row pori print kary ga *** times ke leha sa
}

// FUNCTION TO PRINT CHARACTER 2 (^)
void PrintChar2(char char2, int times)
{
    if (times == 0)
    {
        return;
    }
    else
    {
        cout << char2;
    }
    PrintChar2(char2, times - 1);     //even row mai ho ga to times mai sa 1 minus kary ga or row pori print kary ga ^^^^ times ke leha sa
}

// Function to print the 1pattern
void Pattern1(char char1, char char2, int n, int k)
{
    if (n > k)
    {
        return;
    }
    // In this part, an increasing pattern is printed
    if (n % 2 == 1)
    {
        PrintChar2(char2, n);       // agr odd row ho gi to char1(*) print kary ga incresing mai
        cout << endl;
    }
    if (n % 2 == 0)
    {
        PrintChar1(char1, n);     //agr even row ho gi to char2 (^) print kary ga increasing mai
        cout << endl;
    }

    Pattern1(char1, char2, n + 1, k);

    // In this part,pattern 1 decresing mai print ho ga
    n--;
    if (n % 2 == 1)     // agr odd row ho gi to char1(*) print kary ga decresing mai
    {
        PrintChar2(char2, n);
        cout << endl;
    }
    if (n % 2 == 0)
    {
        PrintChar1(char1, n); //agr even row ho gi to char2 (^) print kary ga decresing mai
        cout << endl;
    }
}


// Function to print the second pattern
void PrintSpaces(int start, int end)
{
    if (start == end)
    {
        return;
    }
    else
    {
        cout << " ";
        PrintSpaces(start + 1, end);
    }
}
// Function to print the 2 pattern
void Pattern2(int start, int end,char ch)
{
    if (start > end)
        return;
    else
    {
        PrintSpaces(start, end);
        cout << ch;
        cout << endl;
        Pattern2(start + 1, end,ch);
        start--;
        PrintSpaces(start, end);
        cout << ch;
        cout << endl;
    }
}


int main()
{
    int a, b = 0;
    char ch1, ch2;
    int start = 0;
    int end = 0;
    char c;
   
    // pattern 1 ka lia user sa input leni h 
    cout << "Enter values for pattern 1:" << endl;
    cin >> a >> b;
    cout << "Enter character for pattern 1:" << endl;
    cin >> ch1;
    cin >> ch2;

    // pattern 2 ka lia user s ainput leni h 
    cout << "Enter stating and ending values for pattern 2: " << endl;
    cin >> start>> end;
    cout << "Enter character for pattern 2: " << endl;
    cin >> c;

    // Call the first pattern function
    cout << "Here pattern 1 prints" << endl;
    Pattern1(ch1,ch2, a,b);

    // Call the second pattern function
    cout << "Here Pattern 2 prints" << endl;
    Pattern2(start, end,c);

    return 0;
}